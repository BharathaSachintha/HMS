﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Model
{
    public class Functions
    {

        public static string Dashboard = "Dashboard";

        public static string EmployeeMaster = "Employee Master";

        public static string InventoryProduct = "Inventory Products";

        public static string Subject = "Subject";
        
        public static string Hall = "Hall";

        public static string HallAllocation = "Hall Allocation";

        public static string Lecturer = "Lecturer";

        public static string Student = "Student";

        public static string Class = "Class";
        
        public static string UserRegister = "User Register";
        
        public static string DashBoard = "DashBoard";
        
        public static string StudentPayment = "Student Payment";
        
        public static string LecturerPayment = "Lecturer Payment";
    }
}
